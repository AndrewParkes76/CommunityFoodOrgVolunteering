import java.util.*;
import java.io.*;

public class DataManager {
    public static ArrayList<CommunityFoodOrg> readCommunityFoodOrgs(String fileName) {
        ArrayList<CommunityFoodOrg> orgs = new ArrayList<>();


        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;

            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");
                String type = parts[0]; // "Food Bank" or "Food Pantry"
                String id = parts[1];
                String name = parts[2];

                double latitude = Double.parseDouble(parts[3]);
                double longitude = Double.parseDouble(parts[4]);
                String address = parts[5];
                String city = parts[6];
                String state = parts[7];
                String zipCode = parts[8];
                boolean offersTransportation = parts[9].equalsIgnoreCase("yes");
                Location location = new Location(latitude, longitude, address, city, state, zipCode);

                if (type.equals("Food Pantry")) {
                    // Parse Food Pantry data
                    int[] dailyVolunteersNeeded = new int[7];
                    TimeFrame[] dailyOpenHours = new TimeFrame[7];
                    int[] dailyVolunteerSignups = new int[7]; // Default to 0

                    for (int i = 10; i < parts.length; i++) {
                        String[] dayInfo = parts[i].split("@");
                        String dayName = dayInfo[0];
                        String[] start = dayInfo[1].split(":");
                        String[] end = dayInfo[2].split(":");
                        int volunteersNeeded = Integer.parseInt(dayInfo[3]);

                        int dayIndex = CommunityFoodOrg.getStaticDayIndex(dayName); // Use static method
                        dailyOpenHours[dayIndex] = new TimeFrame(
                                Integer.parseInt(start[0]), Integer.parseInt(start[1]),
                                Integer.parseInt(end[0]), Integer.parseInt(end[1])
                        );
                        dailyVolunteersNeeded[dayIndex] = volunteersNeeded;
                    }

                    orgs.add(new FoodPantry(id, name, location, dailyOpenHours, dailyVolunteersNeeded, dailyVolunteerSignups, offersTransportation));

                } else if (type.equals("Food Bank")) {
                    // Parse Food Bank data
                    double maxCapacity = Double.parseDouble(parts[10]);
                    TimeFrame[] dailyOpenHours = new TimeFrame[7];
                    double[] dailyDonationsNeeded = new double[7]; // Default to maxCapacity

                    Arrays.fill(dailyDonationsNeeded, maxCapacity); // Fill default values

                    for (int i = 11; i < parts.length; i++) {
                        String[] dayInfo = parts[i].split("@");
                        String dayName = dayInfo[0];
                        String[] start = dayInfo[1].split(":");
                        String[] end = dayInfo[2].split(":");

                        int dayIndex = CommunityFoodOrg.getStaticDayIndex(dayName); // Use static method
                        dailyOpenHours[dayIndex] = new TimeFrame(
                                Integer.parseInt(start[0]), Integer.parseInt(start[1]),
                                Integer.parseInt(end[0]), Integer.parseInt(end[1])
                        );
                    }

                    orgs.add(new FoodBank(id, name, location, dailyOpenHours, maxCapacity, dailyDonationsNeeded));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return orgs;
    }

    public static ArrayList<Volunteer> readVolunteers(String fileName) {
        ArrayList<Volunteer> volunteers = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");
                String id = parts[0];
                String lastName = parts[1];
                String firstName = parts[2];
                int age = Integer.parseInt(parts[3]);
                double latitude = Double.parseDouble(parts[4]);
                double longitude = Double.parseDouble(parts[5]);
                String address = parts[6];
                String city = parts[7];
                String state = parts[8];
                String zipCode = parts[9];
                String dayAvailable = parts[10];
                String[] start = parts[11].split(":");
                String[] end = parts[12].split(":");
                double distanceAvailable = Double.parseDouble(parts[13]);
                boolean needsTransportation = parts[14].equalsIgnoreCase("yes");
                double donation = Double.parseDouble(parts[15]); // Parse donation field

                Location location = new Location(latitude, longitude, address, city, state, zipCode);
                TimeFrame timeAvailable = new TimeFrame(
                        Integer.parseInt(start[0]), Integer.parseInt(start[1]),
                        Integer.parseInt(end[0]), Integer.parseInt(end[1])
                );

                Volunteer volunteer = new Volunteer(id, firstName + " " + lastName, age, location, dayAvailable, timeAvailable, distanceAvailable, needsTransportation);
                volunteer.setDonation(donation); // Set the donation
                volunteers.add(volunteer);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return volunteers;
    }
}

/**
 * Class CommunityFoodOrgVolunteeringGUI
 * Author: Andrew Parkes
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class CommunityFoodOrgVolunteeringGUI {

    private JFrame frame;
    private JTextField txtFullName, txtAge, txtAvailability, txtLat, txtLong, txtAddress, txtDonation;
    private JComboBox<String> cboDay;
    private JTextField txtStartHour, txtStartMinute, txtEndHour, txtEndMinute;
    private JCheckBox chkNeedsTransportation;
    private JList<String> lstOrganizations;
    private DefaultListModel<String> orgListModel;
    private JButton btnAddVolunteer, btnSignUpVolunteer;

    private VolunteeringManager volManager;

    /**
     * Constructor
     *
     * @param volManager the manager object containing volunteers and organizations
     */
    public CommunityFoodOrgVolunteeringGUI(VolunteeringManager volManager) {
        this.volManager = volManager;

        frame = new JFrame("Community Food Org Volunteering");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 600);
        frame.setLayout(new BorderLayout());

        JPanel pnlTop = new JPanel(new GridLayout(5, 4));
        JLabel lblFullName = new JLabel("Full name:");
        txtFullName = new JTextField();
        JLabel lblAge = new JLabel("Age:");
        txtAge = new JTextField();
        JLabel lblAvailability = new JLabel("Availability up to");
        txtAvailability = new JTextField();
        JLabel lblMiles = new JLabel("miles");
        JLabel lblNeedsTransportation = new JLabel("Needs transportation?");
        chkNeedsTransportation = new JCheckBox();
        JLabel lblDay = new JLabel("Available on:");
        cboDay = new JComboBox<>(new String[]{"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"});
        JLabel lblTimeFrom = new JLabel("From");
        txtStartHour = new JTextField();
        JLabel lblColon1 = new JLabel(":");
        txtStartMinute = new JTextField();
        JLabel lblTimeTo = new JLabel("to");
        txtEndHour = new JTextField();
        JLabel lblColon2 = new JLabel(":");
        txtEndMinute = new JTextField();

        JLabel lblLat = new JLabel("Latitude location:");
        txtLat = new JTextField();
        JLabel lblLong = new JLabel("Longitude location:");
        txtLong = new JTextField();
        JLabel lblAddress = new JLabel("Address:");
        txtAddress = new JTextField();
        JLabel lblDonation = new JLabel("Donation (lbs):");
        txtDonation = new JTextField("0");

        pnlTop.add(lblFullName);
        pnlTop.add(txtFullName);
        pnlTop.add(lblLat);
        pnlTop.add(txtLat);

        pnlTop.add(lblAge);
        pnlTop.add(txtAge);
        pnlTop.add(lblLong);
        pnlTop.add(txtLong);

        pnlTop.add(lblAvailability);
        pnlTop.add(txtAvailability);
        pnlTop.add(lblAddress);
        pnlTop.add(txtAddress);

        pnlTop.add(lblMiles);
        pnlTop.add(new JLabel()); // Empty cell
        pnlTop.add(lblDonation);
        pnlTop.add(txtDonation);

        pnlTop.add(lblNeedsTransportation);
        pnlTop.add(chkNeedsTransportation);
        pnlTop.add(lblDay);
        pnlTop.add(cboDay);

        JPanel pnlTime = new JPanel(new FlowLayout());
        pnlTime.add(lblTimeFrom);
        pnlTime.add(txtStartHour);
        pnlTime.add(lblColon1);
        pnlTime.add(txtStartMinute);
        pnlTime.add(lblTimeTo);
        pnlTime.add(txtEndHour);
        pnlTime.add(lblColon2);
        pnlTime.add(txtEndMinute);

        JPanel pnlBottom = new JPanel(new BorderLayout());
        orgListModel = new DefaultListModel<>();
        lstOrganizations = new JList<>(orgListModel);
        JScrollPane scrollPane = new JScrollPane(lstOrganizations);
        btnAddVolunteer = new JButton("Add volunteer");
        btnSignUpVolunteer = new JButton("Sign up volunteer");

        pnlBottom.add(scrollPane, BorderLayout.CENTER);
        JPanel pnlButtons = new JPanel(new GridLayout(1, 2));
        pnlButtons.add(btnAddVolunteer);
        pnlButtons.add(btnSignUpVolunteer);
        pnlBottom.add(pnlButtons, BorderLayout.SOUTH);

        frame.add(pnlTop, BorderLayout.NORTH);
        frame.add(pnlTime, BorderLayout.CENTER);
        frame.add(pnlBottom, BorderLayout.SOUTH);

        btnAddVolunteer.addActionListener(e -> addVolunteer());
        btnSignUpVolunteer.addActionListener(e -> signUpVolunteer());

        frame.setVisible(true);
    }

    /**
     * Adds a new volunteer based on the GUI fields
     */
    private void addVolunteer() {
        try {
            String name = txtFullName.getText();
            int age = Integer.parseInt(txtAge.getText());
            double availability = Double.parseDouble(txtAvailability.getText());
            boolean needsTransportation = chkNeedsTransportation.isSelected();
            String dayAvailable = (String) cboDay.getSelectedItem();
            int startHour = Integer.parseInt(txtStartHour.getText());
            int startMinute = Integer.parseInt(txtStartMinute.getText());
            int endHour = Integer.parseInt(txtEndHour.getText());
            int endMinute = Integer.parseInt(txtEndMinute.getText());
            double lat = Double.parseDouble(txtLat.getText());
            double lng = Double.parseDouble(txtLong.getText());
            String address = txtAddress.getText();
            double donation = Double.parseDouble(txtDonation.getText());

            Location location = new Location(lat, lng, address, "", "", "");
            TimeFrame timeFrame = new TimeFrame(startHour, startMinute, endHour, endMinute);
            Volunteer volunteer = new Volunteer("", name, age, location, dayAvailable, timeFrame, availability, needsTransportation);
            volunteer.setDonation(donation);

            volManager.getVolunteers().add(volunteer);
            updateOrgList(volunteer);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Please enter valid input for all fields.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Updates the organization list to show matches for the volunteer
     *
     * @param volunteer the volunteer to find matches for
     */
    private void updateOrgList(Volunteer volunteer) {
        orgListModel.clear();
        ArrayList<CommunityFoodOrg> matches = volManager.findMatches(volunteer);
        for (CommunityFoodOrg org : matches) {
            orgListModel.addElement(org.getName());
        }
    }

    /**
     * Signs up the selected volunteer to the selected organization
     */
    private void signUpVolunteer() {
        int selectedIndex = lstOrganizations.getSelectedIndex();
        if (selectedIndex == -1) {
            JOptionPane.showMessageDialog(frame, "Please select an organization.", "Selection Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        CommunityFoodOrg selectedOrg = volManager.getOrgs().get(selectedIndex);
        Volunteer volunteer = volManager.getVolunteers().get(volManager.getVolunteers().size() - 1);

        if (selectedOrg.signUpVolunteer(volunteer)) {
            JOptionPane.showMessageDialog(frame, "Volunteer signed up successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(frame, "Failed to sign up volunteer.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}